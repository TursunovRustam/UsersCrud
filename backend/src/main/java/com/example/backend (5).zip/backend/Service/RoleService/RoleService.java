package com.example.backend.Service.RoleService;

import com.example.backend.Entity.Role;

import java.util.List;

public interface RoleService {
    List<Role> getRoles();
}
