package com.example.backend.Service.AvatarImg;

import com.example.backend.Entity.AvatarImg;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

public interface AvatarImgService {
    AvatarImg getAvatarImgById(UUID id);
    AvatarImg saveImg(MultipartFile file);
    AvatarImg editImg(MultipartFile file, UUID id);
}
