package com.example.backend.Service.UserService;

import com.example.backend.DTO.UserDTO;
import com.example.backend.Entity.Role;
import com.example.backend.Payload.LoginReq;
import com.example.backend.Projection.UserProjection;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.List;

public interface UserService {
    List<UserProjection> getUsers();
    void register(UserDTO userData);
    String login(LoginReq loginData);

    UserDetails getUserByUsername(String token);

    List<Role> getAllRoles();
}
