package com.example.backend.Controller;

import com.example.backend.API.ResAPI;
import com.example.backend.DTO.IncomeProductDTO;
import com.example.backend.Entity.IncomeProduct;
import com.example.backend.Service.IncomeProduct.IncomeProductService;
import com.example.backend.Service.IncomeProduct.IncomeProductServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/income-product")
public class IncomeProductController {
    @Autowired
    private IncomeProductService incomeProductService;

    @PostMapping
    public ResAPI incomeProduct(@RequestBody IncomeProductDTO incomeProductData){
        return new ResAPI("income product", true, incomeProductService.incomeProduct(incomeProductData));
    }

    @PatchMapping("{type}")
    private ResAPI editProduct(@PathVariable String type, @RequestBody  IncomeProductDTO incomeProductData){
       if (type.equals("balance")){
           System.out.println(incomeProductData);
           return new ResAPI("balance", true, incomeProductService.incomeProduct(incomeProductData));
        }
        return new ResAPI("not found product", true, null);
    }
}
