package com.example.backend.Controller;

import com.example.backend.API.ResAPI;
import com.example.backend.Entity.ExpenseProduct;
import com.example.backend.Repo.ExpenseProductsRepo;
import com.example.backend.Service.ExpenseProduct.ExpenseProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/expenseProduct")
public class ExpenseProductsController {
    @Autowired
    public ExpenseProductService expenseProductService;
    @PostMapping
    private ResAPI saveAllOrders(@RequestBody List<ExpenseProduct> expenseProduct){
        expenseProductService.saveAll(expenseProduct);
        return new ResAPI("ok", true, null);
    }
}