package com.example.backend.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "expense_product")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExpenseProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @OneToOne
    private Product product;
    private Integer count;
    private LocalDateTime createdAt;
}
