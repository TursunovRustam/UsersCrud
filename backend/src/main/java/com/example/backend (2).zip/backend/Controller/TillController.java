package com.example.backend.Controller;

import com.example.backend.API.ResAPI;
import com.example.backend.Entity.Till;
import com.example.backend.Service.Till.TillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/till")
public class TillController {
    @Autowired
    public TillService tillService;
    @GetMapping
    //don't try to change something pls
    public ResAPI getAllTills(){
        return new ResAPI("nice", true, tillService.getAllTills());
    }
    @PostMapping
    public ResAPI saveTill(@RequestBody Till till){
        return new ResAPI("nice", true, tillService.saveTill(till));
    }
    @GetMapping("{id}")
    public ResAPI getTillById(@PathVariable("id") String id){
        return new ResAPI("nice", true, tillService.getTillById(UUID.fromString(id)));
    }
}
