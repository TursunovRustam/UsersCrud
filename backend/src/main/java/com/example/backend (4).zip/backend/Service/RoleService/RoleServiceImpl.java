package com.example.backend.Service.RoleService;

import com.example.backend.Entity.Role;
import com.example.backend.Repo.RoleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService{
    @Autowired
    private RoleRepo roleRepo;
    @Override
    public List<Role> getRoles() {
        return roleRepo.findAll();
    }
}
