package com.example.backend.Service.UserService;

import com.example.backend.DTO.UserDTO;
import com.example.backend.Entity.Role;
import com.example.backend.Entity.User;
import com.example.backend.Payload.LoginReq;
import com.example.backend.Projection.UserProjection;
import com.example.backend.Repo.AvatarImgRepo;
import com.example.backend.Repo.RoleRepo;
import com.example.backend.Repo.UserRepo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    @Autowired
    AuthenticationConfiguration authenticationConfiguration;
    @Autowired
    UserDetailsService userDetailsService;
    @Autowired
    UserRepo usersRepo;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    RoleRepo roleRepo;
    @Autowired
    AvatarImgRepo avatarImgRepo;

    public static String secretKey = "timurrustamulugbektimurabdusobirjahongir";

    public UserServiceImpl(UserRepo usersRepo) {
        this.usersRepo = usersRepo;
    }

    @Override
    public String login(LoginReq loginReq) {
        try {
            UserDetails userDetails = userDetailsService.loadUserByUsername(loginReq.getUsername());
            System.out.println(userDetails);
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                    userDetails,
                    loginReq.getPassword(),
                    userDetails.getAuthorities()
            );

            authenticationConfiguration.getAuthenticationManager().authenticate(authenticationToken);

            String token = Jwts
                    .builder()
                    .setIssuer(userDetails.getUsername())
                    .setIssuedAt(new Date(System.currentTimeMillis()))
                    .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 24 * 365))
                    .signWith(Keys.hmacShaKeyFor(secretKey.getBytes()))
                    .compact();
            return token;
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @Override
    public UserDetails getUserByUsername(String token) {
        String usernameByToken = findUsernameByToken(token);
        UserDetails byUsername = usersRepo.findByUsername(usernameByToken);
        return byUsername;
    }
    public String findUsernameByToken(String token){
        Claims body = Jwts
                .parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(secretKey.getBytes()))
                .build()
                .parseClaimsJws(token)
                .getBody();
        return body.get("iss").toString();
    }

    @Override
    public List<UserProjection> getUsers() {
        return usersRepo.getUsers();
    }

    @Override
    public void register(UserDTO userData) {
        Role role = roleRepo.findByName("ROLE_ADMIN");
        System.out.println(role);
        List<Role> roles = new ArrayList<>();
        roles.add(role);
        usersRepo.save(new User(
                null,
                userData.getUsername(),
                passwordEncoder.encode(userData.getPassword()),
                roles
        ));
    }
}
