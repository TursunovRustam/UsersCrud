package com.example.backend.Controller;

import com.example.backend.API.PrinterUse;
import com.example.backend.API.ResAPI;
import com.example.backend.DTO.FilterDTO;
import com.example.backend.DTO.PrinterDTO;
import com.example.backend.DTO.ProductDTO;
import com.example.backend.Projection.ProductProjection;
import com.example.backend.Service.ProductService.ProductServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.print.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Base64;

@RestController
@RequestMapping("/api/product")
public class ProductController {
    @Autowired
    private ProductServiceImpl productService;

    @GetMapping
    private ResAPI getProducts(){
        return new ResAPI("get all products", true, productService.getProducts());
    }

    @GetMapping("/{productId}")
    private ResAPI getProductCard(@PathVariable String productId){
        ProductProjection productCard = productService.getProductCard(productId);
        return new ResAPI("get product card", true, productCard);
    }
    @GetMapping("/getAllCards")
    private ResAPI getAllCards(){
        return new ResAPI("nicex2", true, productService.getProductCardOfAllProduct());
    }

    @PostMapping
    private ResAPI saveProduct(@RequestBody ProductDTO productData){
        return new ResAPI("save product", true, productService.saveProduct(productData));
    }
    @PostMapping("/print")
    private ResAPI print(@RequestBody PrinterDTO printerDTO) throws PrintException {
        String base64Image = printerDTO.getBase64();
        String[] parts = base64Image.split(",");
        String imageBase64 = parts[1];
        ImageIcon imageIcon = null;
        try {
            byte[] imageBytes = Base64.getDecoder().decode(imageBase64);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
            BufferedImage image = ImageIO.read(bis);
            ImageIcon icon = new ImageIcon(image);
            JLabel label = new JLabel(icon);
            imageIcon = icon;
            System.out.println("Image conversion successful.");
        } catch (IOException e) {
            System.out.println("Error occurred during image conversion: " + e.getMessage());
        }
        PrintService service = PrintServiceLookup.lookupDefaultPrintService();
        DocPrintJob job = service.createPrintJob();
        DocFlavor flavor = DocFlavor.SERVICE_FORMATTED.PRINTABLE;
        SimpleDoc doc = new SimpleDoc(new PrinterUse(imageIcon), flavor, null);
        job.print(doc, null);
        return new ResAPI("NICE", true, null);
    }

    @PatchMapping
    private ResAPI editProduct(@RequestBody ProductDTO productData){
        productService.updateProductData(productData);
        return new ResAPI();
    }
    @PatchMapping("/getByFilter")
    private ResAPI getByFilter(@RequestBody FilterDTO filterDTO){
        System.out.println(filterDTO);
        return new ResAPI("filter", true, productService.getProductsByFilter(filterDTO));
    }
}
