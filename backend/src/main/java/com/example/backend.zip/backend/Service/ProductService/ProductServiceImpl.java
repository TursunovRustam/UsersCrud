package com.example.backend.Service.ProductService;

import com.example.backend.DTO.FilterDTO;
import com.example.backend.DTO.ProductDTO;
import com.example.backend.Entity.AvatarImg;
import com.example.backend.Entity.Category;
import com.example.backend.Entity.IncomeProduct;
import com.example.backend.Entity.Product;
import com.example.backend.Payload.SearchData;
import com.example.backend.Projection.ProductProjection;
import com.example.backend.Projection.ProductProjectionGetAll;
import com.example.backend.Repo.AvatarImgRepo;
import com.example.backend.Repo.CategoryRepo;
import com.example.backend.Repo.IncomeProductRepo;
import com.example.backend.Repo.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepo productRepo;
    @Autowired
    private CategoryRepo categoryRepo;
    @Autowired
    private IncomeProductRepo incomeProductRepo;
    @Autowired
    private AvatarImgRepo imgRepo;


    @Override
    public Product saveProduct(ProductDTO productData) {
        Category category = categoryRepo.findById(productData.getCategoryId()).get();
        AvatarImg avatarImg = imgRepo.findById(productData.getImgId()).get();
        Product savedProduct = productRepo.save(new Product(null, productData.getName(), category, productData.getCode(), productData.getPrice(), avatarImg));
        return savedProduct;
    }

    @Override
    public List<Product> getProducts() {
        return productRepo.findAll();
    }


    @Override
    public ProductProjection getProductCard(String incomeId) {
        return productRepo.getProductCard(UUID.fromString(incomeId));
    }

    @Override
    public List<ProductProjectionGetAll> getProductCardOfAllProduct() {
        List<ProductProjectionGetAll> countOfAllProducts = productRepo.getCountOfAllProducts();
        return countOfAllProducts;
    }


    @Override
    public Product updateProductData(ProductDTO productDTO) {
        System.out.println(productDTO);
        Product byCode = productRepo.findByCode(productDTO.getCode());
        IncomeProduct byProductId = incomeProductRepo.findByProductId(byCode.getId());
        byProductId.setCount(productDTO.getBalance());
        byProductId.setIncomePrice(productDTO.getIncomePrice());
        incomeProductRepo.save(byProductId);
        byCode.setName(productDTO.getName());
        byCode.setPrice(productDTO.getPrice());
        byCode.setCode(productDTO.getCode());
        Product save = productRepo.save(byCode);
        return save;
    }
    @Override
    public List<Product> searchProducts(SearchData searchData) {
        return productRepo.findAllByNameContainingIgnoreCaseOrCodeOrCategory_Id(searchData.getName(), searchData.getCode(), searchData.getCategoryId());
    }


    @Override
    public List<ProductProjectionGetAll> getProductsByFilter(FilterDTO filterDTO) {
        List<ProductProjectionGetAll> productList = null;
        if (filterDTO.getCategoryId() != null && !filterDTO.getSearch().isEmpty()) {
            productList = productRepo.findAllByCategory_IdAndNameContainingIgnoreCase(
                    filterDTO.getCategoryId(), filterDTO.getSearch()
            );
        } else if (filterDTO.getCategoryId() != null) {
            productList = productRepo.findAllByCategory_Id(filterDTO.getCategoryId());
        } else if (!filterDTO.getSearch().isEmpty()) {
            productList = productRepo.findAllByNameContainingIgnoreCase(filterDTO.getSearch());
        } else {
            productList = productRepo.getCountOfAllProducts();
        }
        return productList;
    }
}
