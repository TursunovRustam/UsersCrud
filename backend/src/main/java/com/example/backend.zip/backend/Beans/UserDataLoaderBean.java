package com.example.backend.Beans;

import com.example.backend.Entity.Role;
import com.example.backend.Entity.User;
import com.example.backend.Repo.RoleRepo;
import com.example.backend.Repo.UserRepo;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserDataLoaderBean implements CommandLineRunner {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private RoleRepo roleRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        roleRepo.save(new Role(
                null,
                "ROLE_ADMIN"
        ));
        Role roleSuperAdmin = roleRepo.save(new Role(
                null,
                "ROLE_SUPER_ADMIN"
        ));
        List<Role> roles = new ArrayList<>();
        roles.add(roleSuperAdmin);
        String username = "ecommerce-admin";
        String password = "root123";
        userRepo.save(new User(
                null,
                username,
                passwordEncoder.encode(password),
                roles
        ));
    }
}
