package com.example.backend.Controller;

import com.example.backend.API.ResAPI;
import com.example.backend.DTO.CategoryDTO;
import com.example.backend.Entity.Category;
import com.example.backend.Repo.CategoryRepo;
import com.example.backend.Service.Category.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/category")
public class CategoryController {
    @Autowired
    CategoryService categoryService;
    @PreAuthorize("hasAnyRole('ROLE_SUPER_ADMIN')")
    @PostMapping
    ResAPI saveCategory(@RequestBody CategoryDTO categoryData){
        return new ResAPI("save category", true, categoryService.saveCategory(categoryData));
    }

    @GetMapping
    ResAPI getCategories(){
        return new ResAPI("get categories", true, categoryService.getAll());
    }
}
