package com.example.backend.Controller;

import com.example.backend.API.ResAPI;
import com.example.backend.Service.AvatarImg.AvatarImgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.UUID;

@RestController
@RequestMapping("/api/avatarImg")
public class AvatarImgController {
    @Autowired
    private AvatarImgService avatarImgService;

    @GetMapping("{id}")
    public ResAPI getAvatarImg(@PathVariable String id){
        return new ResAPI("saved img", true, avatarImgService.getAvatarImgById(UUID.fromString(id)));
    }

    @PostMapping
    public ResAPI saveAvatarImg(@RequestParam MultipartFile file) {
        return new ResAPI("saved img", true, avatarImgService.saveImg(file).getId());
    }

    @PutMapping("{imgId}")
    public ResAPI changeAvatarImg(@RequestParam MultipartFile file, @PathVariable String imgId) {
        return new ResAPI("saved img", true, avatarImgService.editImg(file, UUID.fromString(imgId)).getId());
    }
}
