package com.example.backend.Projection;

import com.example.backend.Entity.Category;
import org.springframework.beans.factory.annotation.Value;

import java.util.UUID;

public interface ProductProjectionGetAll {
    @Value("#{target.product_id.toString()}")
    String getId();
    @Value("#{target.name}")
    String getName();
    @Value("#{target.code}")
    String getCode();
    @Value("#{target.price}")
    Integer getPrice();
    @Value("#{target.img_id}")
    UUID getImgId();
    @Value("#{target.balance}")
    Integer getBalance();
    @Value("#{target.category_id}")
    UUID getCategoryId();
    @Value("#{target.category_name}")
    String getCategoryName();
}