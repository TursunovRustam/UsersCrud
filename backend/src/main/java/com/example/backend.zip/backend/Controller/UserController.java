package com.example.backend.Controller;

import com.example.backend.API.ResAPI;
import com.example.backend.DTO.UserDTO;
import com.example.backend.Payload.LoginReq;
import com.example.backend.Service.UserService.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    private UserServiceImpl userService;
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @GetMapping
    public ResAPI getUsers() {
        return new ResAPI("register", true, userService.getUsers());
    }

    @PostMapping("/register")
    public ResAPI register(@RequestBody UserDTO userData) {
        userService.register(userData);
        return new ResAPI("register", true, null);
    }

    @PostMapping("/login")
    public ResAPI login(@RequestBody LoginReq loginData) {
        System.out.println(loginData);
        String token = userService.login(loginData);
        return new ResAPI("login", true, token);
    }
    @GetMapping("/getRole")
    public ResAPI getRole(@RequestHeader("token") String token){
        System.out.println(token);
        return new ResAPI("role", true, userService.getUserByUsername(token).getAuthorities());
    }
}
