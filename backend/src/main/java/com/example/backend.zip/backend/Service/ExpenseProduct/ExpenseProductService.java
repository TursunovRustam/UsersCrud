package com.example.backend.Service.ExpenseProduct;

import com.example.backend.Entity.ExpenseProduct;

import java.util.List;

public interface ExpenseProductService {
    List<ExpenseProduct> saveAll(List<ExpenseProduct> expenseProduct);
}
